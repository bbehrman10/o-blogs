define(["resources/ethers.js", 'text!resources/contractabi.json'], function(ethers, abiString) {
  'use strict';

  class PageModule {}
  const contractAddress = "0x06A3F540004A2ba928fcba915D41fF32C084B57b";
  const contractABI = JSON.parse(abiString).abi;
   PageModule.prototype.checkIfWalletIsConnected = async function () {
        try {
          const {ethereum} = window;
          if (!ethereum) {
          console.log("Make sure you have metamask");
          } else {
            console.log("We have the ethereum object", ethereum);
          }
          const accounts = await ethereum.request({method: "eth_accounts"});
          if (accounts.length !== 0) {
            const account = accounts[0];
            console.log("Found an authorized account", account);
            return account;
          } else {
            console.log("No authorized account found");
          }
        } catch (error) {
          console.log(error);
        }
    };
  PageModule.prototype.connectWallet = async function () {
    try {
          const {ethereum} = window;
          if (!ethereum) {
          alert("Get MetaMask");
          return;
          }
          const accounts = await ethereum.request({method: "eth_requestAccounts"});
          console.log("Connected", accounts[0]);
          return accounts[0];
        } catch (error) {
          console.log(error);
        }
  };
  PageModule.prototype.readContractString = async function () {
    try { 
      const {ethereum} = window;
      if (ethereum) { 
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(contractAddress, contractABI, signer);

        let response = await contract.message();
        console.log(response);
        return response;
        
      }
    } catch (error) {
      console.log(error);
    }
  };
  PageModule.prototype.setContractString = async function (newString) {
    try { 
      const {ethereum} = window;
      if (ethereum) { 
        const provider = new ethers.providers.Web3Provider(ethereum);
        const signer = provider.getSigner();
        const contract = new ethers.Contract(contractAddress, contractABI, signer);

        let response = await contract.update(newString);
        console.log(response);
        return response;
        
      }
    } catch (error) {
      console.log(error);
    }
  }
 
  
  return PageModule;
});
