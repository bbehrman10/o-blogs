define(["resources/ethers", 'text!resources/contractabi.json'], function(ethers, abiString) {
  'use strict';

  class AppModule {
  }
  
  return AppModule;
});
